import React from "react";
import Header from "../componants/Header";
import AboutHero from "./../componants/AboutHero";
import VIdeoTestiMon from "../componants/VIdeoTestiMon";
import Experience from "../componants/Experience";

function Testemonial() {
  return (
    <div style={{ background: "#151515" }} className=" overflow-hidden">
      <Header nav_tab_onhover_Testimo="nav_tab_onhover_ActivePage" />
      <AboutHero />
      <VIdeoTestiMon />
      <Experience />
    </div>
  );
}

export default Testemonial;
