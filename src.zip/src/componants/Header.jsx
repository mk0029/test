import React, { useState } from "react";
import logo from "../assets/img/svg/logo.svg";
import { Link } from "react-router-dom";

function Header(props) {
  const [navShow, setNavShow] = useState(false);
  if (navShow) {
    document.body.style.overflow = "hidden";
  } else {
    document.body.style.overflow = "initial";
  }
  return (
    <section id="Header" className="w-100">
      <nav>
        <div className="container ">
          <div className="d-flex justify-content-between align-items-center pt-sm-4 pt-3">
            <ul className="mb-0 p-0">
              <a href="#">
                <img className="logo_size" src={logo} alt="LOGO-ICON" />
              </a>
            </ul>

            <div
              className={
                navShow
                  ? "threeline d-lg-none cursor_pointer"
                  : "threeline d-lg-none cursor_pointer"
              }
              onClick={() => setNavShow(!navShow)}>
              <div
                className={navShow ? " falseline1" : "  threelinechild"}></div>
              <div className={navShow ? "falseline" : " threelinechild"}></div>
              <div className={navShow ? "falseline3 " : "threelinechild"}></div>
            </div>

            <ul className="mb-0 p-0 d-flex gap-4 ms-xl-5 d-none d-lg-flex">
              <li>
                <Link
                  className={`ff_jakarta fw-normal fs_md text-white nav_tab_onhover position-relative opacity_07 transition px-1 ${props.nav_tab_onhover_ActivePage}`}
                  to="/">
                  Home
                </Link>
              </li>
              <li>
                <Link
                  to="/About"
                  className={`ff_jakarta fw-normal fs_md text-white nav_tab_onhover position-relative opacity_07 transition px-1 ${props.nav_tab_onhover_About}`}>
                  About
                </Link>
              </li>
              <li>
                <Link
                  to="/Testimonials"
                  className={`ff_jakarta fw-normal fs_md text-white nav_tab_onhover position-relative opacity_07 transition px-1 ${props.nav_tab_onhover_Testimo}`}
                  href="#">
                  Testimonials
                </Link>
              </li>
              <li>
                <a
                  className={`ff_jakarta fw-normal fs_md text-white nav_tab_onhover position-relative opacity_07 transition px-1 ${props.nav_tab_onhover_Location}`}
                  href="#">
                  Location
                </a>
              </li>
              <li>
                <a
                  className={`ff_jakarta fw-normal fs_md text-white nav_tab_onhover position-relative opacity_07 transition px-1 ${props.nav_tab_onhover_About}`}
                  href="#">
                  Process
                </a>
              </li>
            </ul>
            <ul className="d-flex gap-1 mb-0 p-0 mb-0 d-none d-lg-flex">
              <button className="ff_jakarta fw-semibold text-white fs_md common_btn">
                Contact Us
              </button>
            </ul>
          </div>
          <div
            className={
              navShow
                ? "shownav d-flex flex-column justify-content-center align-items-center"
                : "hidenav d-flex flex-column justify-content-center align-items-center"
            }>
            <ul className="mb-0 p-0 d-flex gap-4 flex-column justify-content-center align-items-center">
              {" "}
              <li>
                <a
                  className={`ff_jakarta fw-normal fs_md text-white nav_tab_onhover position-relative transition px-1 ${props.nav_tab_onhover_ActivePage}`}
                  href="#">
                  Home
                </a>
              </li>
              <li>
                <a
                  className={`ff_jakarta fw-normal fs_md text-white nav_tab_onhover position-relative transition px-1 ${props.nav_tab_onhover_About}`}
                  href="#">
                  About
                </a>
              </li>
              <li>
                <a
                  className={`ff_jakarta fw-normal fs_md text-white nav_tab_onhover position-relative transition px-1 ${props.nav_tab_onhover_Testimo}`}
                  href="#">
                  Testimonials
                </a>
              </li>
              <li>
                <a
                  className={`ff_jakarta fw-normal fs_md text-white nav_tab_onhover position-relative transition px-1 ${props.nav_tab_onhover_Location}`}
                  href="#">
                  Location
                </a>
              </li>
              <li>
                <a
                  className={`ff_jakarta fw-normal fs_md text-white nav_tab_onhover position-relative transition px-1 ${props.nav_tab_onhover_proses}`}
                  href="#">
                  Process
                </a>
              </li>
            </ul>
            <ul className="d-flex gap-1 mb-0 p-0 mb-0 justify-content-center align-items-center mt-4">
              <button className="ff_jakarta fw-semibold text-white fs_md common_btn">
                Contact Us
              </button>
            </ul>
          </div>
        </div>
      </nav>
    </section>
  );
}

export default Header;
